import 'package:flutter/material.dart';
import 'package:get/get.dart';
import '../../routes/app_routes.dart';

class AccountScreen extends StatelessWidget {
  const AccountScreen({super.key});
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Account')),
      body: Padding(padding: const EdgeInsets.all(16), child: Column(children: const [ListTile(title: Text('My Account')), ListTile(title: Text('Address')), ListTile(title: Text('Payment methods')),],))
    );
  }
}
