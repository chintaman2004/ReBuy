import 'package:flutter/material.dart';
import 'package:get/get.dart';
import '../../routes/app_routes.dart';
import '../theme/app_theme.dart';

class SignupScreen extends StatelessWidget {
  const SignupScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(G.pad),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: const [
              SizedBox(height: 8),
              Text('Sign up', style: TextStyle(fontSize: 28, fontWeight: FontWeight.w700)),
              SizedBox(height: 16),
              TextField(decoration: InputDecoration(labelText: 'Name')),
              SizedBox(height: 12),
              TextField(decoration: InputDecoration(labelText: 'Email')),
              SizedBox(height: 12),
              TextField(decoration: InputDecoration(labelText: 'Password'), obscureText: true),
              SizedBox(height: 12),
            ],
          ),
        ),
      ),
      bottomNavigationBar: Padding(
        padding: const EdgeInsets.all(G.pad),
        child: PinkButton(text: 'Create account', onPressed: ()=>Get.toNamed(Routes.home)),
      ),
    );
  }
}
