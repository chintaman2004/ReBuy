import 'package:flutter/material.dart';
import 'package:get/get.dart';
import '../../routes/app_routes.dart';
import '../theme/app_theme.dart';

class LoginScreen extends StatelessWidget {
  const LoginScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(G.pad),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const SizedBox(height: 8),
              const Text('Log in', style: TextStyle(fontSize: 28, fontWeight: FontWeight.w700)),
              const SizedBox(height: 16),
              const TextField(decoration: InputDecoration(labelText: 'Email')),
              const SizedBox(height: 12),
              const TextField(decoration: InputDecoration(labelText: 'Password'), obscureText: true),
              const SizedBox(height: 12),
              Align(alignment: Alignment.centerRight, child: TextButton(onPressed: (){}, child: const Text('Forgot Password?'))),
              const SizedBox(height: 8),
              PinkButton(text: 'Log in', onPressed: ()=>Get.toNamed(Routes.home)),
              const SizedBox(height: 16),
              Row(
                children: [
                  Expanded(child: Container(height: 1, color: AppColors.stroke)),
                  const Padding(padding: EdgeInsets.symmetric(horizontal: 8), child: Text('or')),
                  Expanded(child: Container(height: 1, color: AppColors.stroke)),
                ],
              ),
              const SizedBox(height: 12),
              Row(children: [
                _social(Icons.g_mobiledata, 'Google'),
                const SizedBox(width: 12),
                _social(Icons.apple, 'Apple'),
                const SizedBox(width: 12),
                _social(Icons.facebook, 'Facebook'),
              ]),
              const Spacer(),
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  const Text('Don\'t have an account? '),
                  GestureDetector(onTap: ()=>Get.toNamed(Routes.signup), child: const Text('Sign up', style: TextStyle(color: AppColors.pink, fontWeight: FontWeight.w700))),
                ],
              ),
              const SizedBox(height: 8),
            ],
          ),
        ),
      ),
    );
  }

  Widget _social(IconData icon, String label){
    return Expanded(
      child: CardTile(padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10), child: Row(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(icon, size: 20, color: AppColors.text),
          const SizedBox(width: 6),
          Text(label, style: const TextStyle(fontWeight: FontWeight.w600))
        ],
      )),
    );
  }
}
