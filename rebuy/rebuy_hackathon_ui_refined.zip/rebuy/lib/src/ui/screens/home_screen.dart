import 'package:flutter/material.dart';
import 'package:get/get.dart';
import '../../controllers/home_controller.dart';
import '../../routes/app_routes.dart';
import '../theme/app_theme.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});
  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  int _tab = 0;
  @override
  Widget build(BuildContext context) {
    final c = Get.put(HomeController());
    return Scaffold(
      appBar: AppBar(
        automaticallyImplyLeading: false,
        title: const Text('Explore', style: TextStyle(fontWeight: FontWeight.w700)),
        actions: [
          IconButton(onPressed: ()=>Get.toNamed(Routes.messages), icon: const Icon(Icons.message_outlined)),
          IconButton(onPressed: ()=>Get.toNamed(Routes.sidebar), icon: const Icon(Icons.menu)),
        ],
      ),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.all(G.pad),
            child: TextField(
              decoration: InputDecoration(
                hintText: 'Search products',
                prefixIcon: const Icon(Icons.search),
              ),
            ),
          ),
          Expanded(
            child: Obx(() {
              if (c.isLoading.value) return const Center(child: CircularProgressIndicator());
              return ListView.separated(
                padding: const EdgeInsets.symmetric(horizontal: G.pad, vertical: 8),
                itemBuilder: (_, i) {
                  final p = c.products[i];
                  return CardTile(
                    child: Row(
                      children: [
                        Container(
                          width: 68, height: 68,
                          decoration: BoxDecoration(
                            borderRadius: G.r16,
                            color: AppColors.bg,
                          ),
                          child: const Icon(Icons.image),
                        ),
                        const SizedBox(width: 12),
                        Expanded(child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(p.title, style: const TextStyle(fontWeight: FontWeight.w700)),
                            const SizedBox(height: 4),
                            Text(p.description, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(color: AppColors.subtext)),
                          ],
                        )),
                        const SizedBox(width: 12),
                        Column(
                          crossAxisAlignment: CrossAxisAlignment.end,
                          children: [
                            Text('Rs ${p.price.toStringAsFixed(0)}', style: const TextStyle(fontWeight: FontWeight.w700)),
                            const SizedBox(height: 8),
                            SizedBox(width: 92, child: PinkButton(text: 'View', onPressed: ()=>Get.toNamed(Routes.product, arguments: p.id))),
                          ],
                        )
                      ],
                    ),
                  );
                },
                separatorBuilder: (_, __) => const SizedBox(height: 10),
                itemCount: c.products.length,
              );
            }),
          ),
        ],
      ),
      bottomNavigationBar: CapsuleTabBar(index: _tab, onChanged: (i){
        setState(()=>_tab=i);
        if(i==1) Get.toNamed(Routes.liked);
        if(i==2) Get.toNamed(Routes.account);
      }),
    );
  }
}
